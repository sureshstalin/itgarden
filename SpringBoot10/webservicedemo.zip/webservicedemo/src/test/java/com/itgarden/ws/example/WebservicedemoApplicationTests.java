package com.itgarden.ws.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebservicedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
